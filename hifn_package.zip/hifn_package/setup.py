"""
Setup configuration for HIFN package

Author: Dr. Mohammed Yousif Kmkhol
Email: kmkhol01@gmail.com
"""

from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="hifn",
    version="1.0.0",
    author="Dr. Mohammed Yousif Kmkhol",
    author_email="kmkhol01@gmail.com",
    description="Hybrid Information Flow Networks - Novel Deep Learning Architecture Learning in Information-Theoretic Space",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/hifn",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Science/Research",
        "Intended Audience :: Developers",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Topic :: Scientific/Engineering :: Information Analysis",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    python_requires=">=3.8",
    install_requires=[
        "torch>=2.0.0",
        "numpy>=1.21.0",
        "matplotlib>=3.5.0",
        "seaborn>=0.12.0",
        "scikit-learn>=1.0.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.0.0",
            "black>=22.0.0",
            "flake8>=4.0.0",
        ],
        "examples": [
            "pandas>=1.4.0",
            "xgboost>=1.6.0",
            "kagglehub>=0.1.0",
        ],
    },
    keywords="deep-learning information-theory machine-learning neural-networks pytorch intrusion-detection cybersecurity",
    project_urls={
        "Bug Reports": "https://github.com/yourusername/hifn/issues",
        "Source": "https://github.com/yourusername/hifn",
        "Documentation": "https://github.com/yourusername/hifn/blob/main/README.md",
    },
)
