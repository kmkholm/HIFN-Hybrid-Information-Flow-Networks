# HIFN Package - Quick Start Guide

**Author:** Dr. Mohammed Yousif Kmkhol  
**Email:** kmkhol01@gmail.com  
**Version:** 1.0.0

---

## 📦 What You Have

A complete, pip-installable Python package for **HIFN (Hybrid Information Flow Networks)** - a novel deep learning architecture that learns in information-theoretic space.

### Package Contents

```
hifn_package/
├── hifn/                           # Main package
│   ├── __init__.py                 # Package initialization
│   ├── core.py                     # Core HIFN implementation
│   └── visualize.py                # Visualization tools
├── examples/                       # Example scripts
│   ├── mnist_example.py            # Simple MNIST example
│   └── cicids2017_example.py       # Full CICIDS2017 example
├── setup.py                        # Package installation config
├── README.md                       # Complete documentation
├── LICENSE                         # MIT License
├── INSTALL.md                      # Installation guide
├── PYPI_GUIDE.md                   # Publishing guide
├── MANIFEST.in                     # Package manifest
└── requirements.txt                # Dependencies
```

---

## 🚀 Installation (3 Options)

### Option 1: Local Development Install

```bash
cd hifn_package
pip install -e .
```

### Option 2: Build and Install

```bash
cd hifn_package
python -m pip install build
python -m build
pip install dist/hifn-1.0.0-py3-none-any.whl
```

### Option 3: Publish to PyPI (See PYPI_GUIDE.md)

```bash
# Build
python -m build

# Upload to PyPI
pip install twine
twine upload dist/*

# Then anyone can install:
pip install hifn
```

---

## ✅ Verify Installation

```python
import hifn
print(f"HIFN version: {hifn.__version__}")
print(f"Author: {hifn.__author__}")
print(f"Email: {hifn.__email__}")

# Output:
# HIFN version: 1.0.0
# Author: Dr. Mohammed Yousif Kmkhol
# Email: kmkhol01@gmail.com
```

---

## 💡 Basic Usage

### Example 1: Simple Classification

```python
from hifn import HIFN, HIFNTrainer, HIFNVisualizer
import torch
from torch.utils.data import DataLoader

# Create model
model = HIFN(
    input_dim=100,              # Your feature dimension
    hidden_dims=[64, 32],       # Hidden layer sizes
    num_classes=10,             # Number of classes
    beta_init=0.01             # Information retention rate
)

# Setup device
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

# Train
trainer = HIFNTrainer(
    model=model,
    learning_rate=0.001,
    beta_weight=0.001,
    device=device
)

history = trainer.fit(
    train_loader=your_train_loader,
    val_loader=your_val_loader,
    epochs=30
)

# Visualize
HIFNVisualizer.plot_training_history(history)
```

### Example 2: CICIDS2017 (Complete Example)

```bash
cd examples
python cicids2017_example.py
```

This will:
1. Load CICIDS2017 dataset
2. Train HIFN model
3. Generate 6 publication-quality plots:
   - Class distribution
   - Training history
   - Information flow analysis
   - Confusion matrix
   - Per-class metrics
   - Feature importance

---

## 📊 Running Examples

### MNIST Example (Simple)

```bash
cd examples
python mnist_example.py
```

**Expected output:**
- Accuracy: ~98%
- Training time: ~5-10 minutes on GPU
- Generates 3 plots

### CICIDS2017 Example (Full)

```bash
cd examples
python cicids2017_example.py
```

**Expected output:**
- Accuracy: ~99%+
- Training time: Varies by dataset size
- Generates 6 plots

---

## 🎨 Visualization Options

```python
from hifn import HIFNVisualizer

# 1. Training curves
HIFNVisualizer.plot_training_history(history, save_path='training.png')

# 2. Information flow (Novel!)
sample = next(iter(test_loader))[0][:32]
fig, summary = HIFNVisualizer.plot_information_flow(
    model, sample, save_path='info_flow.png'
)
print(f"Total Information: {summary['total_information_bits']:.2f} bits")

# 3. Confusion matrix
HIFNVisualizer.plot_confusion_matrix(
    y_true, y_pred, class_names, save_path='confusion.png'
)

# 4. Per-class metrics
HIFNVisualizer.plot_classification_report(
    y_true, y_pred, class_names, save_path='metrics.png'
)

# 5. Feature importance (Novel!)
HIFNVisualizer.plot_feature_importance(
    model, feature_names, top_k=20, save_path='importance.png'
)
```

---

## 🔧 Adapting to Your Data

### For Tabular Data

```python
from sklearn.preprocessing import StandardScaler, LabelEncoder
from torch.utils.data import TensorDataset, DataLoader

# Your data: X (features), y (labels)
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

encoder = LabelEncoder()
y_encoded = encoder.fit_transform(y)

# Create DataLoader
dataset = TensorDataset(
    torch.FloatTensor(X_scaled),
    torch.LongTensor(y_encoded)
)
loader = DataLoader(dataset, batch_size=128, shuffle=True)

# Use with HIFN
model = HIFN(
    input_dim=X.shape[1],
    hidden_dims=[128, 64],
    num_classes=len(encoder.classes_)
)
```

### For Images (with CNN)

```python
import torch.nn as nn

class HIFNConvNet(nn.Module):
    def __init__(self, num_classes=10):
        super().__init__()
        
        # CNN feature extractor
        self.features = nn.Sequential(
            nn.Conv2d(3, 64, 3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(2),
        )
        
        # HIFN classifier
        from hifn import HIFN
        self.hifn = HIFN(
            input_dim=64*14*14,
            hidden_dims=[256, 128],
            num_classes=num_classes
        )
    
    def forward(self, x, return_metrics=False):
        x = self.features(x)
        x = x.view(x.size(0), -1)
        return self.hifn(x, return_metrics)
```

---

## 📝 Key Parameters

### Model Parameters

| Parameter | Description | Default | Range |
|-----------|-------------|---------|-------|
| `input_dim` | Number of features | Required | - |
| `hidden_dims` | List of layer sizes | Required | [64, 128, 256, 512] |
| `num_classes` | Number of classes | Required | - |
| `beta_init` | Information retention | 0.01 | 0.001-0.1 |

### Trainer Parameters

| Parameter | Description | Default | Range |
|-----------|-------------|---------|-------|
| `learning_rate` | Optimizer LR | 0.001 | 0.0001-0.01 |
| `beta_weight` | Info loss weight | 0.001 | 0.0001-0.01 |
| `device` | CPU or CUDA | 'cpu' | - |

---

## 🎓 What Makes HIFN Novel?

### Traditional Networks

```python
# Learn: Weights and biases
weights, biases
```

### HIFN (Novel!)

```python
# Learn: Information-theoretic parameters
β                    # Information retention rate
entropy_budget       # Maximum information capacity
compression_ratio    # Dimensionality reduction
info_gates          # Per-neuron control
```

### Key Innovations

1. **Learns in information space** (not weight/activation space)
2. **Intrinsically interpretable** (not post-hoc like LIME/SHAP)
3. **Adaptive compression** (learns optimal compression per layer)
4. **Information flow analysis** (visualize information through network)

---

## 📚 File Descriptions

### Core Files

- **`hifn/core.py`**: Main HIFN implementation
  - `InformationBottleneckLayer`: Novel layer with info-theoretic learning
  - `HIFN`: Complete model architecture
  - `HIFNTrainer`: Training framework

- **`hifn/visualize.py`**: Visualization tools
  - `plot_training_history()`: Loss/accuracy curves
  - `plot_information_flow()`: Novel info flow analysis
  - `plot_confusion_matrix()`: Confusion matrix
  - `plot_classification_report()`: Per-class metrics
  - `plot_feature_importance()`: Feature importance from gates

### Documentation

- **`README.md`**: Complete package documentation
- **`INSTALL.md`**: Installation instructions
- **`PYPI_GUIDE.md`**: Publishing to PyPI guide
- **`LICENSE`**: MIT License

### Examples

- **`examples/mnist_example.py`**: Simple MNIST demo
- **`examples/cicids2017_example.py`**: Full intrusion detection example

---

## 🐛 Troubleshooting

### Import Error

```bash
# Reinstall
pip install -e . --force-reinstall
```

### CUDA Out of Memory

```python
# Reduce batch size
train_loader = DataLoader(dataset, batch_size=64)  # Instead of 256
```

### NaN Losses

```python
# Reduce learning rate and beta
model = HIFN(..., beta_init=0.001)
trainer = HIFNTrainer(model, learning_rate=0.0001, beta_weight=0.0001)
```

---

## 📧 Support

**Author:** Dr. Mohammed Yousif Kmkhol  
**Email:** kmkhol01@gmail.com  
**Institution:** Ajloun National University, Jordan  
**Position:** Assistant Professor of Cybersecurity and Cloud Computing

For issues, questions, or collaboration:
- Email: kmkhol01@gmail.com
- Include "HIFN" in subject line

---

## 🚀 Next Steps

1. **Install the package** (Option 1, 2, or 3 above)
2. **Run MNIST example** to verify installation
3. **Try CICIDS2017 example** for full demonstration
4. **Adapt to your data** using the templates
5. **Publish to PyPI** (optional, see PYPI_GUIDE.md)

---

## 📖 Citation

```bibtex
@software{hifn2025,
  title={HIFN: Hybrid Information Flow Networks},
  author={Kmkhol, Mohammed Yousif},
  year={2025},
  version={1.0.0},
  email={kmkhol01@gmail.com}
}
```

---

**Ready to use! Install and start learning in information-theoretic space! 🎉**
