"""
HIFN Applied to CICIDS2017 Network Intrusion Detection
Complete Example with Visualization

Author: Dr. Mohammed Yousif Kmkhol
Email: kmkhol01@gmail.com

This example demonstrates HIFN on the CICIDS2017 dataset for
multi-class network intrusion detection.
"""

import os
import numpy as np
import pandas as pd
import warnings
warnings.filterwarnings('ignore')

import torch
from torch.utils.data import TensorDataset, DataLoader

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.metrics import classification_report, accuracy_score, f1_score

import matplotlib.pyplot as plt
import seaborn as sns

# Import HIFN
from hifn import HIFN, HIFNTrainer, HIFNVisualizer

print("="*80)
print("HIFN: Hybrid Information Flow Networks")
print("Applied to CICIDS2017 Network Intrusion Detection")
print("="*80)
print(f"Author: Dr. Mohammed Yousif Kmkhol")
print(f"Email: kmkhol01@gmail.com")
print("="*80)


# ============================================================
# STEP 1: LOAD AND PREPROCESS DATA
# ============================================================

def load_cicids2017_data(data_dir):
    """Load and concatenate all CICIDS2017 CSV files."""
    
    csv_files = [
        "Friday-WorkingHours-Afternoon-DDos.pcap_ISCX.csv",
        "Friday-WorkingHours-Afternoon-PortScan.pcap_ISCX.csv",
        "Friday-WorkingHours-Morning.pcap_ISCX.csv",
        "Monday-WorkingHours.pcap_ISCX.csv",
        "Thursday-WorkingHours-Afternoon-Infilteration.pcap_ISCX.csv",
        "Thursday-WorkingHours-Morning-WebAttacks.pcap_ISCX.csv",
        "Tuesday-WorkingHours.pcap_ISCX.csv",
        "Wednesday-workingHours.pcap_ISCX.csv"
    ]
    
    print("\nLoading CICIDS2017 dataset...")
    df_list = []
    
    for file in csv_files:
        file_path = os.path.join(data_dir, file)
        if os.path.exists(file_path):
            print(f"  Loading: {file}")
            temp_df = pd.read_csv(file_path)
            df_list.append(temp_df)
        else:
            print(f"  Warning: {file} not found")
    
    df = pd.concat(df_list, axis=0, ignore_index=True)
    print(f"\n✓ Combined Dataset Shape: {df.shape}")
    
    return df


def preprocess_data(df):
    """Clean and preprocess the dataset."""
    
    print("\n" + "="*80)
    print("DATA PREPROCESSING")
    print("="*80)
    
    # Standardize column names
    df.columns = df.columns.str.strip()
    
    if "Label" not in df.columns:
        raise ValueError("Column 'Label' not found!")
    
    # Clean labels
    df["Label"] = df["Label"].astype(str).str.strip()
    
    print(f"\nClass distribution:")
    class_counts = df["Label"].value_counts()
    for label, count in class_counts.items():
        print(f"  {label:30s}: {count:,}")
    
    # Plot class distribution
    plt.figure(figsize=(12, 6))
    plt.bar(range(len(class_counts)), class_counts.values, color='steelblue', edgecolor='navy')
    plt.xticks(range(len(class_counts)), class_counts.index, rotation=45, ha='right')
    plt.title("CICIDS2017 Class Distribution", fontsize=14, fontweight='bold')
    plt.ylabel("Number of Samples")
    plt.xlabel("Attack Type")
    plt.grid(True, alpha=0.3, axis='y')
    plt.tight_layout()
    plt.savefig('cicids_class_distribution.png', dpi=300, bbox_inches='tight')
    print("\n✓ Saved class distribution plot")
    
    # Handle infinite values
    print("\nHandling infinite values...")
    df.replace([np.inf, -np.inf], np.nan, inplace=True)
    
    # Drop NaN
    print("Dropping NaN values...")
    df_clean = df.dropna()
    print(f"✓ Shape after cleaning: {df_clean.shape}")
    
    # Separate features and labels
    feature_cols = df_clean.select_dtypes(include=[np.number]).columns.tolist()
    feature_cols = [c for c in feature_cols if "label" not in c.lower()]
    
    X = df_clean[feature_cols].values
    
    # Encode labels
    label_encoder = LabelEncoder()
    y = label_encoder.fit_transform(df_clean["Label"].values)
    class_names = list(label_encoder.classes_)
    
    print(f"\n{'='*80}")
    print(f"DATASET INFO:")
    print(f"{'='*80}")
    print(f"Total Samples:      {len(X):,}")
    print(f"Number of Classes:  {len(class_names)}")
    print(f"Number of Features: {len(feature_cols)}")
    
    return X, y, class_names, feature_cols


def create_data_loaders(X, y, batch_size=256, test_size=0.2):
    """Create PyTorch data loaders."""
    
    print("\n" + "="*80)
    print("CREATING DATA LOADERS")
    print("="*80)
    
    # Scale features
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    
    # Train/test split (stratified)
    X_train, X_test, y_train, y_test = train_test_split(
        X_scaled, y, test_size=test_size, random_state=42, stratify=y
    )
    
    print(f"Train samples: {len(X_train):,}")
    print(f"Test samples:  {len(X_test):,}")
    
    # Convert to PyTorch tensors
    train_dataset = TensorDataset(
        torch.FloatTensor(X_train),
        torch.LongTensor(y_train)
    )
    test_dataset = TensorDataset(
        torch.FloatTensor(X_test),
        torch.LongTensor(y_test)
    )
    
    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
    test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)
    
    print(f"✓ Data loaders created (batch_size={batch_size})")
    
    return train_loader, test_loader, X_test, y_test


# ============================================================
# STEP 2: BUILD AND TRAIN HIFN MODEL
# ============================================================

def build_hifn_model(input_dim, num_classes, device):
    """Build HIFN model for intrusion detection."""
    
    print("\n" + "="*80)
    print("BUILDING HIFN MODEL")
    print("="*80)
    
    model = HIFN(
        input_dim=input_dim,
        hidden_dims=[256, 128, 64],  # Information bottleneck architecture
        num_classes=num_classes,
        beta_init=0.01  # Initial information retention rate
    )
    
    print(f"\nModel Architecture:")
    print(model)
    
    print(f"\n✓ Novel Information-Theoretic Parameters:")
    for name, param in model.named_parameters():
        if any(x in name for x in ['beta', 'entropy', 'compression', 'info_gates']):
            print(f"  {name}: {param.shape}")
    
    return model


def train_hifn(model, train_loader, test_loader, device, epochs=30):
    """Train HIFN model."""
    
    print("\n" + "="*80)
    print("TRAINING HIFN")
    print("="*80)
    
    trainer = HIFNTrainer(
        model=model,
        learning_rate=0.001,
        beta_weight=0.0001,  # Weight for information-theoretic loss
        device=device
    )
    
    history = trainer.fit(
        train_loader=train_loader,
        val_loader=test_loader,
        epochs=epochs,
        verbose=True
    )
    
    return trainer, history


# ============================================================
# STEP 3: EVALUATE AND VISUALIZE
# ============================================================

def evaluate_model(trainer, test_loader, class_names):
    """Evaluate trained model."""
    
    print("\n" + "="*80)
    print("MODEL EVALUATION")
    print("="*80)
    
    # Get predictions
    y_pred, y_true = trainer.predict(test_loader)
    
    # Compute metrics
    accuracy = accuracy_score(y_true, y_pred)
    f1_macro = f1_score(y_true, y_pred, average='macro')
    f1_weighted = f1_score(y_true, y_pred, average='weighted')
    
    print(f"\n{'='*80}")
    print(f"FINAL RESULTS:")
    print(f"{'='*80}")
    print(f"Accuracy:        {accuracy*100:.2f}%")
    print(f"F1-Score (Macro):    {f1_macro:.4f}")
    print(f"F1-Score (Weighted): {f1_weighted:.4f}")
    
    # Detailed classification report
    print(f"\n{'='*80}")
    print("CLASSIFICATION REPORT:")
    print(f"{'='*80}")
    print(classification_report(y_true, y_pred, target_names=class_names))
    
    return y_pred, y_true


def visualize_results(trainer, history, test_loader, y_pred, y_true, class_names, feature_names):
    """Create all visualizations."""
    
    print("\n" + "="*80)
    print("GENERATING VISUALIZATIONS")
    print("="*80)
    
    # 1. Training history
    print("\n1. Plotting training history...")
    HIFNVisualizer.plot_training_history(history, save_path='hifn_training_history.png')
    
    # 2. Information flow analysis
    print("2. Plotting information flow...")
    sample_batch = next(iter(test_loader))[0][:32]
    fig, summary = HIFNVisualizer.plot_information_flow(
        trainer.model, 
        sample_batch, 
        save_path='hifn_information_flow.png'
    )
    
    print(f"\n   Information Flow Summary:")
    print(f"   Total Information: {summary['total_information_bits']:.2f} bits")
    print(f"   Compression Ratios: {[f'{c:.3f}' for c in summary['compression_ratios']]}")
    print(f"   Layer Entropies: {[f'{e:.2f}' for e in summary['layer_entropies']]}")
    
    # 3. Confusion matrix
    print("\n3. Plotting confusion matrix...")
    HIFNVisualizer.plot_confusion_matrix(
        y_true, y_pred, class_names, 
        save_path='hifn_confusion_matrix.png'
    )
    
    # 4. Per-class metrics
    print("4. Plotting per-class metrics...")
    HIFNVisualizer.plot_classification_report(
        y_true, y_pred, class_names, 
        save_path='hifn_classification_report.png'
    )
    
    # 5. Feature importance
    print("5. Plotting feature importance...")
    fig, top_indices, top_scores = HIFNVisualizer.plot_feature_importance(
        trainer.model, feature_names, top_k=20,
        save_path='hifn_feature_importance.png'
    )
    
    print(f"\n   Top 5 Most Informative Features:")
    for i in range(min(5, len(top_indices))):
        idx = top_indices[i]
        score = top_scores[i]
        feat_name = feature_names[idx] if idx < len(feature_names) else f"Feature {idx}"
        print(f"   {i+1}. {feat_name}: {score:.4f}")
    
    print("\n✓ All visualizations saved!")


# ============================================================
# MAIN EXECUTION
# ============================================================

def main():
    """Main execution function."""
    
    # Check if running in Kaggle or local
    try:
        import kagglehub
        print("\nDownloading CICIDS2017 dataset from Kaggle...")
        data_dir = kagglehub.dataset_download("chethuhn/network-intrusion-dataset")
        print(f"✓ Dataset downloaded to: {data_dir}")
    except:
        print("\nPlease provide path to CICIDS2017 data directory:")
        data_dir = input("Data directory path: ")
    
    # Load data
    df = load_cicids2017_data(data_dir)
    
    # Preprocess
    X, y, class_names, feature_names = preprocess_data(df)
    
    # Create data loaders
    train_loader, test_loader, X_test, y_test = create_data_loaders(X, y)
    
    # Setup device
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"\n✓ Using device: {device}")
    
    # Build model
    input_dim = X.shape[1]
    num_classes = len(class_names)
    model = build_hifn_model(input_dim, num_classes, device)
    
    # Train
    trainer, history = train_hifn(model, train_loader, test_loader, device, epochs=30)
    
    # Evaluate
    y_pred, y_true = evaluate_model(trainer, test_loader, class_names)
    
    # Visualize
    visualize_results(trainer, history, test_loader, y_pred, y_true, class_names, feature_names)
    
    print("\n" + "="*80)
    print("HIFN CICIDS2017 EXAMPLE COMPLETE!")
    print("="*80)
    print("\nGenerated files:")
    print("  - cicids_class_distribution.png")
    print("  - hifn_training_history.png")
    print("  - hifn_information_flow.png")
    print("  - hifn_confusion_matrix.png")
    print("  - hifn_classification_report.png")
    print("  - hifn_feature_importance.png")
    print("\nThank you for using HIFN!")
    print(f"Author: Dr. Mohammed Yousif Kmkhol (kmkhol01@gmail.com)")


if __name__ == "__main__":
    main()
