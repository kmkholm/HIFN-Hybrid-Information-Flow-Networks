"""
Simple MNIST Example with HIFN
Demonstrates basic usage on a standard dataset

Author: Dr. Mohammed Yousif Kmkhol
Email: kmkhol01@gmail.com
"""

import torch
from torch.utils.data import DataLoader
from torchvision import datasets, transforms

from hifn import HIFN, HIFNTrainer, HIFNVisualizer

print("="*80)
print("HIFN: Hybrid Information Flow Networks - MNIST Example")
print("="*80)
print(f"Author: Dr. Mohammed Yousif Kmkhol")
print(f"Email: kmkhol01@gmail.com")
print("="*80)

# Data preparation
transform = transforms.Compose([
    transforms.ToTensor(),
    transforms.Normalize((0.1307,), (0.3081,)),
    transforms.Lambda(lambda x: x.view(-1))  # Flatten
])

print("\nDownloading MNIST dataset...")
train_dataset = datasets.MNIST('./data', train=True, download=True, transform=transform)
test_dataset = datasets.MNIST('./data', train=False, transform=transform)

train_loader = DataLoader(train_dataset, batch_size=128, shuffle=True)
test_loader = DataLoader(test_dataset, batch_size=128, shuffle=False)

print(f"✓ Train samples: {len(train_dataset):,}")
print(f"✓ Test samples: {len(test_dataset):,}")

# Setup device
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f"\n✓ Using device: {device}")

# Create HIFN model
print("\nBuilding HIFN model...")
model = HIFN(
    input_dim=784,           # 28x28 flattened
    hidden_dims=[256, 128, 64],
    num_classes=10,
    beta_init=0.01
)

print(model)

# Train
print("\nTraining HIFN...")
trainer = HIFNTrainer(
    model=model,
    learning_rate=0.001,
    beta_weight=0.001,
    device=device
)

history = trainer.fit(
    train_loader=train_loader,
    val_loader=test_loader,
    epochs=20,
    verbose=True
)

# Evaluate
print("\nEvaluating model...")
y_pred, y_true = trainer.predict(test_loader)
accuracy = (y_pred == y_true).mean() * 100

print(f"\n{'='*80}")
print(f"FINAL ACCURACY: {accuracy:.2f}%")
print(f"{'='*80}")

# Visualizations
print("\nGenerating visualizations...")

# 1. Training history
HIFNVisualizer.plot_training_history(history, save_path='mnist_training.png')

# 2. Information flow
sample_batch = next(iter(test_loader))[0][:32]
fig, summary = HIFNVisualizer.plot_information_flow(
    model, sample_batch, save_path='mnist_info_flow.png'
)

print(f"\nInformation Flow Summary:")
print(f"  Total Information: {summary['total_information_bits']:.2f} bits")
print(f"  Compression Ratios: {[f'{c:.3f}' for c in summary['compression_ratios']]}")

# 3. Confusion matrix
class_names = [str(i) for i in range(10)]
HIFNVisualizer.plot_confusion_matrix(
    y_true, y_pred, class_names, save_path='mnist_confusion.png'
)

print("\n✓ All visualizations saved!")
print("\nGenerated files:")
print("  - mnist_training.png")
print("  - mnist_info_flow.png")
print("  - mnist_confusion.png")

print("\n" + "="*80)
print("MNIST Example Complete!")
print("="*80)
print(f"Thank you for using HIFN!")
print(f"Author: Dr. Mohammed Yousif Kmkhol (kmkhol01@gmail.com)")
