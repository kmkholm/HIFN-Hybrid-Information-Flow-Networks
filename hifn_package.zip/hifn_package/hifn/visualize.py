"""
HIFN Visualization Module

Author: Dr. Mohammed Yousif Kmkhol
Email: kmkhol01@gmail.com
"""

import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
from typing import Dict, Optional
import torch

sns.set_style("whitegrid")


class HIFNVisualizer:
    """Visualization tools for analyzing information flow."""
    
    @staticmethod
    def plot_training_history(history: Dict, save_path: Optional[str] = None):
        """Plot training and validation metrics over epochs."""
        fig, axes = plt.subplots(2, 2, figsize=(14, 10))
        
        # Loss curves
        axes[0, 0].plot(history['train_loss'], label='Train Loss', linewidth=2, color='blue')
        axes[0, 0].plot(history['val_loss'], label='Val Loss', linewidth=2, color='orange')
        axes[0, 0].set_xlabel('Epoch', fontsize=12)
        axes[0, 0].set_ylabel('Loss', fontsize=12)
        axes[0, 0].set_title('Classification Loss', fontsize=14, fontweight='bold')
        axes[0, 0].legend()
        axes[0, 0].grid(True, alpha=0.3)
        
        # Accuracy curves
        axes[0, 1].plot(history['train_acc'], label='Train Acc', linewidth=2, color='green')
        axes[0, 1].plot(history['val_acc'], label='Val Acc', linewidth=2, color='red')
        axes[0, 1].set_xlabel('Epoch', fontsize=12)
        axes[0, 1].set_ylabel('Accuracy (%)', fontsize=12)
        axes[0, 1].set_title('Classification Accuracy', fontsize=14, fontweight='bold')
        axes[0, 1].legend()
        axes[0, 1].grid(True, alpha=0.3)
        
        # Information loss
        axes[1, 0].plot(history['info_loss'], color='purple', linewidth=2)
        axes[1, 0].set_xlabel('Epoch', fontsize=12)
        axes[1, 0].set_ylabel('Information Loss', fontsize=12)
        axes[1, 0].set_title('Information-Theoretic Loss (Novel)', fontsize=14, fontweight='bold')
        axes[1, 0].grid(True, alpha=0.3)
        
        # Combined view
        ax2 = axes[1, 1]
        ax2.plot(history['train_loss'], label='CE Loss', linewidth=2, color='blue')
        ax2_twin = ax2.twinx()
        ax2_twin.plot(history['info_loss'], color='red', label='Info Loss', linewidth=2, linestyle='--')
        ax2.set_xlabel('Epoch', fontsize=12)
        ax2.set_ylabel('CE Loss', color='blue', fontsize=12)
        ax2_twin.set_ylabel('Info Loss', color='red', fontsize=12)
        ax2.set_title('Combined Loss View', fontsize=14, fontweight='bold')
        ax2.grid(True, alpha=0.3)
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
            print(f"✓ Saved training history to {save_path}")
        
        return fig
    
    @staticmethod
    def plot_information_flow(model, sample_input: torch.Tensor, save_path: Optional[str] = None):
        """Visualize how information flows through network layers."""
        model.eval()
        device = next(model.parameters()).device
        sample_input = sample_input.to(device)
        
        with torch.no_grad():
            _, layer_metrics = model(sample_input, return_metrics=True)
        
        summary = model.get_information_flow_summary(layer_metrics)
        
        fig, axes = plt.subplots(1, 3, figsize=(16, 5))
        
        # Entropy per layer
        layers = list(range(len(summary['layer_entropies'])))
        axes[0].bar(layers, summary['layer_entropies'], color='skyblue', edgecolor='navy', linewidth=2)
        axes[0].set_xlabel('Layer', fontsize=12)
        axes[0].set_ylabel('Entropy (bits)', fontsize=12)
        axes[0].set_title('Information Content per Layer', fontsize=14, fontweight='bold')
        axes[0].set_xticks(layers)
        axes[0].grid(True, alpha=0.3, axis='y')
        
        # Compression ratios
        axes[1].plot(layers, summary['compression_ratios'], marker='o', linewidth=3, markersize=10, color='green')
        axes[1].set_xlabel('Layer', fontsize=12)
        axes[1].set_ylabel('Compression Ratio', fontsize=12)
        axes[1].set_title('Learned Compression Ratios', fontsize=14, fontweight='bold')
        axes[1].set_xticks(layers)
        axes[1].grid(True, alpha=0.3)
        axes[1].set_ylim([0, 1])
        
        # KL Divergence
        axes[2].bar(layers, summary['layer_kl_divs'], color='coral', edgecolor='darkred', linewidth=2)
        axes[2].set_xlabel('Layer', fontsize=12)
        axes[2].set_ylabel('KL Divergence', fontsize=12)
        axes[2].set_title('Information Cost per Layer', fontsize=14, fontweight='bold')
        axes[2].set_xticks(layers)
        axes[2].grid(True, alpha=0.3, axis='y')
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
            print(f"✓ Saved information flow to {save_path}")
        
        return fig, summary
    
    @staticmethod
    def plot_confusion_matrix(y_true, y_pred, class_names, save_path: Optional[str] = None):
        """Plot confusion matrix."""
        from sklearn.metrics import confusion_matrix
        
        cm = confusion_matrix(y_true, y_pred)
        
        fig, ax = plt.subplots(figsize=(12, 10))
        sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=class_names, 
                    yticklabels=class_names, ax=ax, cbar_kws={'label': 'Count'})
        ax.set_xlabel('Predicted Label', fontsize=12)
        ax.set_ylabel('True Label', fontsize=12)
        ax.set_title('Confusion Matrix - HIFN', fontsize=14, fontweight='bold')
        plt.xticks(rotation=45, ha='right')
        plt.yticks(rotation=0)
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
            print(f"✓ Saved confusion matrix to {save_path}")
        
        return fig
    
    @staticmethod
    def plot_classification_report(y_true, y_pred, class_names, save_path: Optional[str] = None):
        """Plot classification metrics per class."""
        from sklearn.metrics import precision_recall_fscore_support
        
        precision, recall, f1, support = precision_recall_fscore_support(y_true, y_pred, average=None)
        
        x = np.arange(len(class_names))
        width = 0.25
        
        fig, ax = plt.subplots(figsize=(14, 6))
        ax.bar(x - width, precision, width, label='Precision', color='skyblue')
        ax.bar(x, recall, width, label='Recall', color='lightcoral')
        ax.bar(x + width, f1, width, label='F1-Score', color='lightgreen')
        
        ax.set_xlabel('Class', fontsize=12)
        ax.set_ylabel('Score', fontsize=12)
        ax.set_title('Per-Class Metrics - HIFN', fontsize=14, fontweight='bold')
        ax.set_xticks(x)
        ax.set_xticklabels(class_names, rotation=45, ha='right')
        ax.legend()
        ax.grid(True, alpha=0.3, axis='y')
        ax.set_ylim([0, 1.05])
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
            print(f"✓ Saved classification report to {save_path}")
        
        return fig
    
    @staticmethod
    def plot_feature_importance(model, feature_names, top_k=20, save_path: Optional[str] = None):
        """Plot feature importance based on information gates."""
        first_layer = model.layers[0]
        info_gates = torch.sigmoid(first_layer.info_gates_logit).detach().cpu().numpy()
        
        # Normalize to get importance scores
        importance_scores = info_gates / info_gates.sum()
        
        # Get top-k features
        top_indices = importance_scores.argsort()[-top_k:][::-1]
        top_scores = importance_scores[top_indices]
        top_names = [feature_names[i] if i < len(feature_names) else f"Feature {i}" 
                     for i in top_indices]
        
        fig, ax = plt.subplots(figsize=(12, 8))
        y_pos = np.arange(len(top_names))
        ax.barh(y_pos, top_scores, color='teal', edgecolor='darkslategray', linewidth=1.5)
        ax.set_yticks(y_pos)
        ax.set_yticklabels(top_names)
        ax.invert_yaxis()
        ax.set_xlabel('Importance Score', fontsize=12)
        ax.set_title(f'Top {top_k} Most Informative Features (HIFN)', fontsize=14, fontweight='bold')
        ax.grid(True, alpha=0.3, axis='x')
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
            print(f"✓ Saved feature importance to {save_path}")
        
        return fig, top_indices, top_scores
