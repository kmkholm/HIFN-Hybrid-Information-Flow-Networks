"""
HIFN: Hybrid Information Flow Networks
Novel Deep Learning Architecture Learning in Information-Theoretic Space

Author: Dr. Mohammed Yousif Kmkhol
Email: kmkhol01@gmail.com
Version: 1.0.0

Installation:
    pip install hifn

Quick Start:
    from hifn import HIFN, HIFNTrainer, HIFNVisualizer
    
    model = HIFN(input_dim=784, hidden_dims=[256, 128], num_classes=10)
    trainer = HIFNTrainer(model)
    history = trainer.fit(train_loader, val_loader, epochs=30)
"""

from .core import (
    HIFN,
    HIFNTrainer,
    InformationBottleneckLayer,
    __version__,
    __author__,
    __email__
)

from .visualize import HIFNVisualizer

__all__ = [
    'HIFN',
    'HIFNTrainer',
    'InformationBottleneckLayer',
    'HIFNVisualizer',
    '__version__',
    '__author__',
    '__email__'
]
