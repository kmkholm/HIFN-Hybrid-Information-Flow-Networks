"""
HIFN: Hybrid Information Flow Networks
Novel Deep Learning Architecture Learning in Information-Theoretic Space

Author: Dr. Mohammed Yousif Kmkhol
Email: kmkhol01@gmail.com
Date: January 2025
Version: 1.0.0
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from typing import Tuple, List, Dict, Optional

__version__ = "1.0.0"
__author__ = "Dr. Mohammed Yousif Kmkhol"
__email__ = "kmkhol01@gmail.com"


class InformationBottleneckLayer(nn.Module):
    """
    Novel layer that learns in information-theoretic space.
    
    Key Innovation: Instead of learning weights/activations, this layer learns:
    1. Information retention rates (β)
    2. Entropy budgets (maximum information capacity)
    3. Compression ratios (learned dimensionality reduction)
    4. Information gates (per-neuron information control)
    """
    
    def __init__(
        self, 
        input_dim: int, 
        output_dim: int, 
        initial_beta: float = 0.01,
        use_stochastic: bool = True
    ):
        super().__init__()
        
        self.encoder_mean = nn.Linear(input_dim, output_dim)
        self.encoder_logvar = nn.Linear(input_dim, output_dim)
        
        nn.init.xavier_normal_(self.encoder_mean.weight, gain=0.5)
        nn.init.constant_(self.encoder_mean.bias, 0.0)
        nn.init.constant_(self.encoder_logvar.weight, 0.0)
        nn.init.constant_(self.encoder_logvar.bias, -3.0)
        
        # Novel learnable parameters
        self.log_beta = nn.Parameter(torch.log(torch.tensor([initial_beta])))
        self.log_entropy_budget = nn.Parameter(
            torch.log(torch.tensor([float(output_dim) * 2.0]))
        )
        self.logit_compression = nn.Parameter(torch.zeros(1))
        self.info_gates_logit = nn.Parameter(torch.ones(output_dim) * 2.0)
        
        self.use_stochastic = use_stochastic
        self.kl_divergence = torch.tensor(0.0)
        self.eps = 1e-6
        
    def reparameterize(self, mu: torch.Tensor, logvar: torch.Tensor) -> torch.Tensor:
        logvar = torch.clamp(logvar, min=-10.0, max=2.0)
        std = torch.exp(0.5 * logvar)
        eps = torch.randn_like(std)
        return mu + eps * std
    
    def compute_entropy_stable(self, x: torch.Tensor) -> torch.Tensor:
        var = x.var(dim=0, unbiased=True) + self.eps
        var = torch.clamp(var, min=self.eps, max=100.0)
        entropy_per_dim = 0.5 * torch.log(2.0 * np.pi * np.e * var)
        total_entropy = torch.clamp(entropy_per_dim.sum(), min=0.0, max=50.0)
        return total_entropy
    
    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, Dict[str, float]]:
        mu = self.encoder_mean(x)
        logvar = self.encoder_logvar(x)
        logvar = torch.clamp(logvar, min=-10.0, max=2.0)
        
        info_gates = torch.sigmoid(self.info_gates_logit)
        gated_mu = mu * info_gates
        
        if self.use_stochastic and self.training:
            z = self.reparameterize(gated_mu, logvar)
        else:
            z = gated_mu
        
        compression = torch.sigmoid(self.logit_compression)
        compression_scaled = 0.3 + 0.7 * compression
        z_compressed = z * compression_scaled
        
        kl_div = -0.5 * torch.mean(1 + logvar - mu.pow(2) - logvar.exp())
        kl_div = torch.clamp(kl_div, min=0.0, max=10.0)
        self.kl_divergence = kl_div
        
        current_entropy = self.compute_entropy_stable(z_compressed)
        entropy_budget = torch.exp(self.log_entropy_budget)
        entropy_penalty = F.relu(current_entropy - entropy_budget) * 0.001
        beta_value = torch.exp(self.log_beta)
        
        info_metrics = {
            'kl_div': kl_div.item(),
            'entropy': current_entropy.item(),
            'beta': beta_value.item(),
            'compression': compression.item(),
            'entropy_budget': entropy_budget.item(),
            'entropy_penalty': entropy_penalty.item()
        }
        
        return z_compressed, info_metrics


class HIFN(nn.Module):
    """
    Hybrid Information Flow Network
    
    Novel architecture that learns in information-theoretic space.
    """
    
    def __init__(
        self, 
        input_dim: int, 
        hidden_dims: List[int], 
        num_classes: int, 
        beta_init: float = 0.01
    ):
        super().__init__()
        
        self.layers = nn.ModuleList()
        
        dims = [input_dim] + hidden_dims
        for i in range(len(dims) - 1):
            self.layers.append(
                InformationBottleneckLayer(
                    dims[i], 
                    dims[i+1], 
                    initial_beta=beta_init,
                    use_stochastic=True
                )
            )
        
        self.classifier = nn.Linear(hidden_dims[-1], num_classes)
        nn.init.xavier_normal_(self.classifier.weight)
        nn.init.constant_(self.classifier.bias, 0.0)
        
        self.log_global_beta = nn.Parameter(torch.log(torch.tensor([beta_init])))
        
    def forward(self, x: torch.Tensor, return_metrics: bool = False):
        layer_metrics = []
        
        for layer in self.layers:
            x, metrics = layer(x)
            x = F.relu(x)
            
            if self.training:
                x = torch.clamp(x, min=-10.0, max=10.0)
            
            layer_metrics.append(metrics)
        
        logits = self.classifier(x)
        
        if return_metrics:
            return logits, layer_metrics
        return logits
    
    def compute_total_information_loss(self, layer_metrics: List[Dict]) -> torch.Tensor:
        total_kl = sum([m['kl_div'] for m in layer_metrics])
        total_entropy_penalty = sum([m['entropy_penalty'] for m in layer_metrics])
        
        global_beta = torch.exp(self.log_global_beta)
        info_loss = global_beta * total_kl + total_entropy_penalty
        
        return torch.clamp(info_loss, min=0.0, max=100.0)
    
    def get_information_flow_summary(self, layer_metrics: List[Dict]) -> Dict:
        summary = {
            'total_information_bits': sum([m['entropy'] for m in layer_metrics]),
            'compression_ratios': [m['compression'] for m in layer_metrics],
            'layer_entropies': [m['entropy'] for m in layer_metrics],
            'layer_kl_divs': [m['kl_div'] for m in layer_metrics]
        }
        return summary


class HIFNTrainer:
    """Training framework for HIFN."""
    
    def __init__(
        self, 
        model: HIFN, 
        learning_rate: float = 0.001, 
        beta_weight: float = 0.001,
        device: str = 'cpu'
    ):
        self.model = model.to(device)
        self.device = device
        self.optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)
        self.beta_weight = beta_weight
        self.history = {
            'train_loss': [], 
            'train_acc': [],
            'val_loss': [], 
            'val_acc': [],
            'info_loss': [], 
            'total_entropy': []
        }
    
    def train_epoch(self, train_loader):
        self.model.train()
        total_loss = 0
        correct = 0
        total = 0
        total_info_loss = 0
        
        for batch_idx, (data, target) in enumerate(train_loader):
            data, target = data.to(self.device), target.to(self.device)
            
            self.optimizer.zero_grad()
            
            output, layer_metrics = self.model(data, return_metrics=True)
            ce_loss = F.cross_entropy(output, target)
            info_loss = self.model.compute_total_information_loss(layer_metrics)
            total_loss_batch = ce_loss + self.beta_weight * info_loss
            
            if torch.isnan(total_loss_batch) or torch.isinf(total_loss_batch):
                continue
            
            total_loss_batch.backward()
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=1.0)
            self.optimizer.step()
            
            total_loss += ce_loss.item()
            total_info_loss += info_loss.item()
            pred = output.argmax(dim=1, keepdim=True)
            correct += pred.eq(target.view_as(pred)).sum().item()
            total += target.size(0)
        
        avg_loss = total_loss / len(train_loader)
        accuracy = 100.0 * correct / total
        avg_info_loss = total_info_loss / len(train_loader)
        
        return avg_loss, accuracy, avg_info_loss
    
    def validate(self, val_loader):
        self.model.eval()
        val_loss = 0
        correct = 0
        total = 0
        
        with torch.no_grad():
            for data, target in val_loader:
                data, target = data.to(self.device), target.to(self.device)
                output = self.model(data)
                val_loss += F.cross_entropy(output, target).item()
                pred = output.argmax(dim=1, keepdim=True)
                correct += pred.eq(target.view_as(pred)).sum().item()
                total += target.size(0)
        
        avg_loss = val_loss / len(val_loader)
        accuracy = 100.0 * correct / total
        
        return avg_loss, accuracy
    
    def fit(self, train_loader, val_loader, epochs: int, verbose: bool = True):
        if verbose:
            print("Training HIFN - Novel Information Flow Architecture\n")
            print("="*70)
        
        for epoch in range(epochs):
            train_loss, train_acc, info_loss = self.train_epoch(train_loader)
            val_loss, val_acc = self.validate(val_loader)
            
            self.history['train_loss'].append(train_loss)
            self.history['train_acc'].append(train_acc)
            self.history['val_loss'].append(val_loss)
            self.history['val_acc'].append(val_acc)
            self.history['info_loss'].append(info_loss)
            
            if verbose and (epoch + 1) % 5 == 0:
                print(f"Epoch {epoch+1}/{epochs}")
                print(f"  Train Loss: {train_loss:.4f} | Train Acc: {train_acc:.2f}%")
                print(f"  Val Loss: {val_loss:.4f} | Val Acc: {val_acc:.2f}%")
                print(f"  Info Loss: {info_loss:.4f}")
                print(f"  Global β: {torch.exp(self.model.log_global_beta).item():.4f}")
                print("-"*70)
        
        if verbose:
            print("\n✓ Training Complete!")
        return self.history
    
    def predict(self, test_loader):
        """Make predictions on test data."""
        self.model.eval()
        all_preds = []
        all_targets = []
        
        with torch.no_grad():
            for data, target in test_loader:
                data = data.to(self.device)
                output = self.model(data)
                pred = output.argmax(dim=1)
                all_preds.extend(pred.cpu().numpy())
                all_targets.extend(target.numpy())
        
        return np.array(all_preds), np.array(all_targets)
