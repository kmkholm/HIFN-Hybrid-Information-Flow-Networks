# Publishing HIFN to PyPI

**Author:** Dr. Mohammed Yousif Kmkhol  
**Email:** kmkhol01@gmail.com

---

## Prerequisites

1. PyPI account: https://pypi.org/account/register/
2. TestPyPI account (optional): https://test.pypi.org/account/register/
3. Install build tools:

```bash
pip install build twine
```

---

## Step 1: Prepare Package

### Update Version (if needed)

Edit `setup.py` and `hifn/__init__.py`:

```python
version="1.0.0"  # Change as needed
```

### Verify Package Structure

```
hifn_package/
├── hifn/
│   ├── __init__.py
│   ├── core.py
│   └── visualize.py
├── examples/
│   ├── mnist_example.py
│   └── cicids2017_example.py
├── setup.py
├── README.md
├── LICENSE
├── MANIFEST.in
└── requirements.txt
```

---

## Step 2: Build Distribution

```bash
# Navigate to package directory
cd hifn_package

# Clean previous builds
rm -rf build/ dist/ *.egg-info

# Build source and wheel distributions
python -m build
```

This creates:
- `dist/hifn-1.0.0.tar.gz` (source distribution)
- `dist/hifn-1.0.0-py3-none-any.whl` (wheel distribution)

---

## Step 3: Test on TestPyPI (Optional but Recommended)

### Upload to TestPyPI

```bash
twine upload --repository testpypi dist/*
```

Enter your TestPyPI credentials when prompted.

### Install from TestPyPI

```bash
pip install --index-url https://test.pypi.org/simple/ --no-deps hifn
```

### Test Installation

```python
import hifn
print(hifn.__version__)

from hifn import HIFN, HIFNTrainer
# Test basic functionality
```

---

## Step 4: Publish to PyPI

### Upload to PyPI

```bash
twine upload dist/*
```

Enter your PyPI credentials when prompted.

### Verify Publication

Visit: https://pypi.org/project/hifn/

---

## Step 5: Install and Test

```bash
# Install from PyPI
pip install hifn

# Test
python -c "import hifn; print(f'HIFN v{hifn.__version__} by {hifn.__author__}')"
```

---

## Using API Tokens (Recommended)

### Create API Token

1. Go to https://pypi.org/manage/account/
2. Scroll to "API tokens"
3. Click "Add API token"
4. Name: "hifn-upload"
5. Scope: "Entire account" or "Project: hifn"
6. Click "Add token"
7. Copy the token (starts with `pypi-`)

### Configure .pypirc

Create or edit `~/.pypirc`:

```ini
[distutils]
index-servers =
    pypi
    testpypi

[pypi]
username = __token__
password = pypi-YOUR-TOKEN-HERE

[testpypi]
username = __token__
password = pypi-YOUR-TEST-TOKEN-HERE
repository = https://test.pypi.org/legacy/
```

### Upload with Token

```bash
twine upload dist/*
```

(No need to enter credentials - uses .pypirc)

---

## Updating the Package

### 1. Update Version Number

In `setup.py`:
```python
version="1.0.1"  # Increment version
```

In `hifn/__init__.py`:
```python
__version__ = "1.0.1"
```

### 2. Update CHANGELOG

Create `CHANGELOG.md`:
```markdown
# Changelog

## [1.0.1] - 2025-01-XX
### Fixed
- Bug fix description

### Added
- New feature description

## [1.0.0] - 2025-01-01
- Initial release
```

### 3. Rebuild and Upload

```bash
# Clean old builds
rm -rf build/ dist/ *.egg-info

# Build new version
python -m build

# Upload to PyPI
twine upload dist/*
```

---

## Automation with GitHub Actions (Optional)

Create `.github/workflows/publish.yml`:

```yaml
name: Publish to PyPI

on:
  release:
    types: [created]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v2
    
    - name: Set up Python
      uses: actions/setup-python@v2
      with:
        python-version: '3.9'
    
    - name: Install dependencies
      run: |
        python -m pip install --upgrade pip
        pip install build twine
    
    - name: Build package
      run: python -m build
    
    - name: Publish to PyPI
      env:
        TWINE_USERNAME: __token__
        TWINE_PASSWORD: ${{ secrets.PYPI_API_TOKEN }}
      run: twine upload dist/*
```

Add `PYPI_API_TOKEN` to GitHub Secrets.

---

## Verification Checklist

Before publishing:

- [ ] All tests pass
- [ ] README is complete and formatted
- [ ] License file included
- [ ] Version number updated
- [ ] Examples work correctly
- [ ] Dependencies listed correctly
- [ ] Package builds without errors
- [ ] Tested on TestPyPI
- [ ] Documentation is accurate

---

## Common Issues

### Issue: "File already exists"

**Solution:** Increment version number - PyPI doesn't allow re-uploading same version

### Issue: "Invalid distribution"

**Solution:** Check setup.py for syntax errors, rebuild package

### Issue: "Authentication failed"

**Solution:** Verify credentials or API token, check .pypirc configuration

### Issue: "Package name already taken"

**Solution:** Choose a different package name in setup.py

---

## Post-Publication

1. **Add Badges to README:**

```markdown
[![PyPI version](https://badge.fury.io/py/hifn.svg)](https://badge.fury.io/py/hifn)
[![Downloads](https://pepy.tech/badge/hifn)](https://pepy.tech/project/hifn)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
```

2. **Announce Release:**
   - Reddit: r/MachineLearning
   - Twitter/X
   - LinkedIn
   - Academic mailing lists

3. **Create Documentation:**
   - GitHub Wiki
   - ReadTheDocs
   - Tutorial notebooks

---

## Support

For deployment issues:
- **Email:** kmkhol01@gmail.com
- **PyPI Help:** https://pypi.org/help/

---

**Good luck with your package publication!**

Dr. Mohammed Yousif Kmkhol
