# HIFN Installation Guide

**Author:** Dr. Mohammed Yousif Kmkhol  
**Email:** kmkhol01@gmail.com

---

## Quick Install

```bash
pip install hifn
```

---

## Installation from Source

### Option 1: Direct Installation

```bash
# Clone the repository
git clone https://github.com/yourusername/hifn.git
cd hifn

# Install in development mode
pip install -e .
```

### Option 2: Build and Install

```bash
# Clone the repository
git clone https://github.com/yourusername/hifn.git
cd hifn

# Build distribution
python setup.py sdist bdist_wheel

# Install from wheel
pip install dist/hifn-1.0.0-py3-none-any.whl
```

---

## Verify Installation

```python
import hifn
print(f"HIFN version: {hifn.__version__}")
print(f"Author: {hifn.__author__}")

# Quick test
from hifn import HIFN, HIFNTrainer
import torch

model = HIFN(input_dim=10, hidden_dims=[32, 16], num_classes=2)
print("✓ HIFN installation successful!")
```

---

## Dependencies

### Core Requirements

- Python >= 3.8
- PyTorch >= 2.0.0
- NumPy >= 1.21.0
- Matplotlib >= 3.5.0
- Seaborn >= 0.12.0
- scikit-learn >= 1.0.0

### Optional (for examples)

- pandas >= 1.4.0
- xgboost >= 1.6.0
- kagglehub >= 0.1.0

Install optional dependencies:

```bash
pip install hifn[examples]
```

---

## GPU Support

HIFN automatically uses CUDA if available:

```python
import torch

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f"Using device: {device}")

# HIFN will use GPU automatically
trainer = HIFNTrainer(model, device=device)
```

For CUDA support, ensure PyTorch is installed with CUDA:

```bash
# Example for CUDA 11.8
pip install torch torchvision --index-url https://download.pytorch.org/whl/cu118
```

---

## Troubleshooting

### PyTorch Installation Issues

If you encounter PyTorch installation issues:

```bash
# CPU only
pip install torch torchvision --index-url https://download.pytorch.org/whl/cpu

# CUDA 11.8
pip install torch torchvision --index-url https://download.pytorch.org/whl/cu118

# CUDA 12.1
pip install torch torchvision --index-url https://download.pytorch.org/whl/cu121
```

### Import Errors

If you get import errors:

```bash
# Reinstall in editable mode
pip install -e . --force-reinstall
```

### Version Conflicts

Create a fresh virtual environment:

```bash
python -m venv hifn_env
source hifn_env/bin/activate  # On Windows: hifn_env\Scripts\activate
pip install hifn
```

---

## Running Examples

After installation, run the CICIDS2017 example:

```bash
cd examples
python cicids2017_example.py
```

Make sure you have the dataset downloaded or the script will prompt you for the path.

---

## Uninstall

```bash
pip uninstall hifn
```

---

## Support

For installation issues:
- **Email:** kmkhol01@gmail.com
- **Issues:** [GitHub Issues](https://github.com/yourusername/hifn/issues)
