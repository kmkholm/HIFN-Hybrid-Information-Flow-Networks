# HIFN: Hybrid Information Flow Networks

[![PyPI version](https://badge.fury.io/py/hifn.svg)](https://badge.fury.io/py/hifn)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)

**A Novel Deep Learning Architecture that Learns in Information-Theoretic Space**

**Author:** Dr. Mohammed Yousif Kmkhol  
**Email:** kmkhol01@gmail.com  
**Version:** 1.0.0

---

## 🎯 What Makes HIFN Novel?

Traditional deep learning models learn in **weight space** or **activation space**. HIFN learns in **information-theoretic space**, directly optimizing:

1. **β (Information Retention Rate)** - How much information to preserve through each layer
2. **Entropy Budgets** - Maximum information capacity constraints per layer
3. **Compression Ratios** - Learned dimensionality reduction rates
4. **Information Gates** - Per-neuron information flow control

### Why This Matters

- **Intrinsic Interpretability**: Unlike post-hoc methods (LIME, SHAP), HIFN is interpretable by design
- **Information Efficiency**: Learns minimal sufficient statistics for classification
- **Adaptive Compression**: Automatically learns optimal compression per layer
- **Theoretical Foundation**: Based on Information Bottleneck Theory

---

## 📦 Installation

### From PyPI (Recommended)

```bash
pip install hifn
```

### From Source

```bash
git clone https://github.com/yourusername/hifn.git
cd hifn
pip install -e .
```

### Dependencies

- Python >= 3.8
- PyTorch >= 2.0.0
- NumPy >= 1.21.0
- Matplotlib >= 3.5.0
- Seaborn >= 0.12.0
- scikit-learn >= 1.0.0

---

## 🚀 Quick Start

```python
from hifn import HIFN, HIFNTrainer, HIFNVisualizer
import torch
from torch.utils.data import DataLoader

# Create model
model = HIFN(
    input_dim=784,           # Number of input features
    hidden_dims=[256, 128, 64],  # Hidden layer dimensions
    num_classes=10,          # Number of output classes
    beta_init=0.01          # Initial information retention rate
)

# Setup trainer
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
trainer = HIFNTrainer(
    model=model,
    learning_rate=0.001,
    beta_weight=0.001,      # Weight for information-theoretic loss
    device=device
)

# Train
history = trainer.fit(
    train_loader=train_loader,
    val_loader=val_loader,
    epochs=30
)

# Visualize training
HIFNVisualizer.plot_training_history(history)

# Analyze information flow
sample_batch = next(iter(val_loader))[0][:32]
fig, summary = HIFNVisualizer.plot_information_flow(model, sample_batch)

print(f"Total Information: {summary['total_information_bits']:.2f} bits")
print(f"Compression Ratios: {summary['compression_ratios']}")
```

---

## 📊 Complete Example: CICIDS2017 Network Intrusion Detection

```python
"""
HIFN applied to CICIDS2017 for multi-class intrusion detection
"""

from hifn import HIFN, HIFNTrainer, HIFNVisualizer
import torch
from torch.utils.data import TensorDataset, DataLoader
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.model_selection import train_test_split

# Load your data
X, y = load_your_data()  # Your data loading function

# Preprocess
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

label_encoder = LabelEncoder()
y_encoded = label_encoder.fit_transform(y)

# Split
X_train, X_test, y_train, y_test = train_test_split(
    X_scaled, y_encoded, test_size=0.2, stratify=y_encoded
)

# Create DataLoaders
train_dataset = TensorDataset(torch.FloatTensor(X_train), torch.LongTensor(y_train))
test_dataset = TensorDataset(torch.FloatTensor(X_test), torch.LongTensor(y_test))

train_loader = DataLoader(train_dataset, batch_size=256, shuffle=True)
test_loader = DataLoader(test_dataset, batch_size=256, shuffle=False)

# Build HIFN
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

model = HIFN(
    input_dim=X_train.shape[1],
    hidden_dims=[256, 128, 64],
    num_classes=len(label_encoder.classes_),
    beta_init=0.01
)

# Train
trainer = HIFNTrainer(model, learning_rate=0.001, beta_weight=0.0001, device=device)
history = trainer.fit(train_loader, test_loader, epochs=30)

# Evaluate
y_pred, y_true = trainer.predict(test_loader)

# Visualize
HIFNVisualizer.plot_training_history(history, save_path='training_history.png')
HIFNVisualizer.plot_confusion_matrix(y_true, y_pred, label_encoder.classes_, 
                                     save_path='confusion_matrix.png')
HIFNVisualizer.plot_classification_report(y_true, y_pred, label_encoder.classes_,
                                         save_path='classification_report.png')

# Information flow analysis
sample_batch = next(iter(test_loader))[0][:32]
fig, summary = HIFNVisualizer.plot_information_flow(model, sample_batch,
                                                     save_path='info_flow.png')

print(f"Accuracy: {(y_pred == y_true).mean()*100:.2f}%")
print(f"Information Flow: {summary['total_information_bits']:.2f} bits")
```

See `examples/cicids2017_example.py` for a complete working example with the CICIDS2017 dataset.

---

## 🎓 Key Concepts

### Information Bottleneck Theory

HIFN implements the Information Bottleneck principle, seeking representations Z that:

1. **Maximize** information about output Y: max I(Z;Y)
2. **Minimize** information about input X: min I(X;Z)

**Objective Function:**
```
L_total = L_classification + β * I(X;Z) + λ * H_penalty

where:
  I(X;Z) = Mutual information (approximated via KL divergence)
  H_penalty = Entropy budget violation penalty
  β = Learnable information retention rate
```

### Novel Learnable Parameters

```python
# Traditional Neural Network learns:
weights, biases

# HIFN learns (in addition to weights):
β                    # Information retention rate per layer
entropy_budget       # Maximum information capacity per layer  
compression_ratio    # Dimensionality reduction rate per layer
info_gates          # Per-neuron information control
```

### Architecture Layers

Each `InformationBottleneckLayer` contains:

- **Encoder Networks**: Map input to latent distribution
- **Information Gates**: Per-dimension information flow control
- **Compression Module**: Learnable compression ratio
- **Entropy Regulator**: Enforce information capacity constraints

---

## 📈 Hyperparameter Guide

### Key Parameters

| Parameter | Description | Typical Range | Recommended Start |
|-----------|-------------|---------------|-------------------|
| `beta_init` | Initial information retention | 0.001 - 0.1 | 0.01 |
| `beta_weight` | Weight of info loss | 0.0001 - 0.01 | 0.001 |
| `learning_rate` | Optimizer learning rate | 0.0001 - 0.01 | 0.001 |
| `hidden_dims` | Layer sizes | Task-dependent | [256, 128, 64] |

### Tuning Guidelines

**Small datasets (<10K samples):**
```python
beta_init = 0.01
beta_weight = 0.001
learning_rate = 0.001
hidden_dims = [128, 64]
```

**Medium datasets (10K-100K samples):**
```python
beta_init = 0.01
beta_weight = 0.0001
learning_rate = 0.0005
hidden_dims = [256, 128, 64]
```

**Large datasets (>100K samples):**
```python
beta_init = 0.005
beta_weight = 0.0001
learning_rate = 0.0001
hidden_dims = [512, 256, 128]
```

---

## 🔧 Advanced Usage

### Custom Architectures

#### CNN + HIFN for Images

```python
import torch.nn as nn

class HIFNConvNet(nn.Module):
    def __init__(self, num_classes=10):
        super().__init__()
        
        self.features = nn.Sequential(
            nn.Conv2d(3, 64, 3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(2),
            nn.Conv2d(64, 128, 3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(2),
        )
        
        self.hifn = HIFN(
            input_dim=128*8*8,
            hidden_dims=[512, 256],
            num_classes=num_classes
        )
    
    def forward(self, x, return_metrics=False):
        x = self.features(x)
        x = x.view(x.size(0), -1)
        return self.hifn(x, return_metrics)
```

#### LSTM + HIFN for Time Series

```python
class HIFNTimeSeries(nn.Module):
    def __init__(self, input_size, num_classes):
        super().__init__()
        
        self.lstm = nn.LSTM(input_size, 128, num_layers=2, batch_first=True)
        
        self.hifn = HIFN(
            input_dim=128,
            hidden_dims=[64, 32],
            num_classes=num_classes
        )
    
    def forward(self, x, return_metrics=False):
        lstm_out, (h_n, _) = self.lstm(x)
        x = h_n[-1]  # Last hidden state
        return self.hifn(x, return_metrics)
```

### Feature Importance Analysis

```python
# Extract feature importance from information gates
first_layer = model.layers[0]
info_gates = torch.sigmoid(first_layer.info_gates_logit).detach().cpu().numpy()

# Normalize to get importance scores
importance_scores = info_gates / info_gates.sum()

# Get top-k features
top_k = 20
top_indices = importance_scores.argsort()[-top_k:][::-1]

for i, idx in enumerate(top_indices):
    print(f"{i+1}. Feature {idx}: {importance_scores[idx]:.4f}")
```

---

## 📊 Visualization Tools

### Available Visualizations

1. **Training History** - Loss and accuracy curves
2. **Information Flow** - Entropy, compression, and KL divergence per layer
3. **Confusion Matrix** - Multi-class prediction matrix
4. **Classification Report** - Per-class precision, recall, F1-score
5. **Feature Importance** - Top informative features based on gates

### Example Usage

```python
from hifn import HIFNVisualizer

# Training history
HIFNVisualizer.plot_training_history(history, save_path='training.png')

# Information flow analysis
sample = next(iter(test_loader))[0][:32]
fig, summary = HIFNVisualizer.plot_information_flow(model, sample, 
                                                     save_path='info_flow.png')

# Confusion matrix
HIFNVisualizer.plot_confusion_matrix(y_true, y_pred, class_names,
                                     save_path='confusion_matrix.png')

# Per-class metrics
HIFNVisualizer.plot_classification_report(y_true, y_pred, class_names,
                                         save_path='metrics.png')

# Feature importance
HIFNVisualizer.plot_feature_importance(model, feature_names, top_k=20,
                                       save_path='importance.png')
```

---

## 🔬 Mathematical Foundation

### Information Bottleneck Objective

```
min L = -I(Z;Y) + β * I(X;Z)
```

### Variational Approximation

HIFN uses variational inference to approximate mutual information:

```
I(X;Z) ≈ KL(q(z|x) || p(z))

where:
  q(z|x) = Encoder distribution (learned)
  p(z) = Prior distribution (standard Gaussian)
```

### Entropy Constraints

Each layer enforces:

```
H(Z) ≤ Budget (learned parameter)

Penalty = max(0, H(Z) - Budget)
```

### Total Loss

```
L_total = CrossEntropy(y_pred, y_true) + 
          β * Σ_layers KL(q(z|x) || p(z)) + 
          λ * Σ_layers H_penalty
```

---

## 📚 Research Applications

HIFN is particularly suitable for:

- **Network Intrusion Detection** (CICIDS2017, NSL-KDD, etc.)
- **Medical Diagnosis** (tabular clinical data)
- **Anomaly Detection** (fraud, outliers)
- **Privacy-Preserving ML** (explicit information control)
- **Interpretable AI** (intrinsic feature importance)
- **Transfer Learning** (quantify transferable information)

---

## 🐛 Troubleshooting

### Common Issues

**NaN losses during training:**
```python
# Reduce beta_init and learning_rate
model = HIFN(..., beta_init=0.001)
trainer = HIFNTrainer(model, learning_rate=0.0001)
```

**Poor convergence:**
```python
# Increase model capacity or reduce regularization
model = HIFN(hidden_dims=[512, 256, 128], ...)
trainer = HIFNTrainer(model, beta_weight=0.00001)
```

**Overfitting:**
```python
# Increase information regularization
trainer = HIFNTrainer(model, beta_weight=0.01)
```

---

## 📖 Citation

If you use HIFN in your research, please cite:

```bibtex
@software{hifn2025,
  title={HIFN: Hybrid Information Flow Networks},
  author={Kmkhol, Mohammed Yousif},
  year={2025},
  version={1.0.0},
  url={https://github.com/yourusername/hifn},
  note={Novel deep learning architecture learning in information-theoretic space}
}
```

---

## 📄 License

MIT License - see LICENSE file for details.

---

## 👤 Author

**Dr. Mohammed Yousif Kmkhol**  
Email: kmkhol01@gmail.com

**Assistant Professor of Cybersecurity and Cloud Computing**  
Ajloun National University, Jordan

---

## 🙏 Acknowledgments

This work builds upon the theoretical foundations of:
- Information Bottleneck Theory (Tishby et al.)
- Variational Information Bottleneck (Alemi et al.)
- Deep Learning and Information Theory (Saxe et al.)

---

## 📞 Support

- **Issues**: [GitHub Issues](https://github.com/yourusername/hifn/issues)
- **Email**: kmkhol01@gmail.com
- **Documentation**: [Full Documentation](https://github.com/yourusername/hifn/blob/main/docs/README.md)

---

**HIFN - Learning What Matters in Information-Theoretic Space** 🚀
